command: ""
refreshFrequency: 300000

render: (output) -> """
  <div id="pm-widget">
    <div class="pm-header">
      <span class="pm-title">2026 Midterms</span>
      <span class="pm-source">polymarket</span>
    </div>
    <div id="pm-markets">
      <div class="pm-loading">Loading markets...</div>
    </div>
    <div id="pm-updated"></div>
  </div>
"""

afterRender: (domEl) ->
  slugs = [
    "which-party-will-win-the-house-in-2026"
    "which-party-will-win-the-senate-in-2026"
    "balance-of-power-2026-midterms"
    "michigan-senate-election-winner"
    "georgia-senate-election-winner"
    "north-carolina-senate-election-winner"
  ]

  labels = [
    "House winner"
    "Senate winner"
    "Balance of power"
    "Michigan Senate"
    "Georgia Senate"
    "North Carolina Senate"
  ]

  extractPartyFromQuestion = (question) ->
    if /democratic party|democrats? win|democrats? control|democrats? take/i.test(question)
      return { name: "Democratic Party", party: "dem" }
    if /republican party|republicans? win|republicans? control|republicans? take/i.test(question)
      return { name: "Republican Party", party: "rep" }
    if /democrat/i.test(question)
      return { name: "Democrat", party: "dem" }
    if /republican/i.test(question)
      return { name: "Republican", party: "rep" }
    return null

  fetchMarkets = ->
    promises = slugs.map((slug) ->
      fetch("http://127.0.0.1:41417/gamma-api.polymarket.com/events?slug=#{slug}")
        .then((r) -> r.json())
        .catch(-> [])
    )

    Promise.all(promises)
      .then((results) ->
        container = domEl.querySelector("#pm-markets")
        updated = domEl.querySelector("#pm-updated")

        html = ""
        for result, idx in results
          try
            events = if Array.isArray(result) then result else [result]
            event = events[0]
            if not event then continue

            markets = event.markets or []

            chosen = null
            chosenPct = null
            chosenParty = null
            chosenPartyClass = null

            for m in markets
              outcomes = if typeof m.outcomes is 'string' then JSON.parse(m.outcomes) else (m.outcomes or [])
              prices = if typeof m.outcomePrices is 'string' then JSON.parse(m.outcomePrices) else (m.outcomePrices or [])
              question = m.question or ""

              isYesNo = outcomes.length > 0 and outcomes.every((o) -> /^(yes|no)$/i.test(o.trim()))

              if isYesNo
                yesIdx = outcomes.findIndex((o) -> /^yes$/i.test(o.trim()))
                if yesIdx >= 0
                  yesPrice = parseFloat(prices[yesIdx] or 0)
                  parsed = extractPartyFromQuestion(question)
                  if parsed and yesPrice > 0.5
                    if not chosen or yesPrice > chosenPct
                      chosen = parsed.name
                      chosenPct = yesPrice
                      chosenPartyClass = parsed.party
              else
                leadOutcome = outcomes[0]
                leadPrice = parseFloat(prices[0] or 0)
                for i in [1...outcomes.length]
                  p = parseFloat(prices[i] or 0)
                  if p > leadPrice
                    leadPrice = p
                    leadOutcome = outcomes[i]
                isDem = /democrat|democratic/i.test(leadOutcome)
                isRep = /republican/i.test(leadOutcome)
                if isDem or isRep
                  chosen = leadOutcome
                  chosenPct = leadPrice
                  chosenPartyClass = if isDem then "dem" else "rep"
                  break

            if not chosen then continue

            pct = Math.round(chosenPct * 100)

            html += """
              <div class="pm-row">
                <div class="pm-question">#{labels[idx]}</div>
                <div class="pm-result">
                  <span class="pm-candidate #{chosenPartyClass}">#{chosen}</span>
                  <span class="pm-pct">#{pct}%</span>
                </div>
                <div class="pm-bar-bg">
                  <div class="pm-bar #{chosenPartyClass}" style="width:#{pct}%"></div>
                </div>
              </div>
            """
          catch e
            continue

        if html is ""
          container.innerHTML = '<div class="pm-loading">No markets found</div>'
          return

        container.innerHTML = html
        now = new Date()
        updated.textContent = "Updated #{now.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}"
      )
      .catch((err) ->
        domEl.querySelector("#pm-markets").innerHTML = '<div class="pm-loading">Failed to load</div>'
      )

  fetchMarkets()

style: """
  left: 20px
  top: 20px
  font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", sans-serif

  #pm-widget
    width: 320px
    background: rgba(15, 15, 20, 0.85)
    backdrop-filter: blur(20px)
    -webkit-backdrop-filter: blur(20px)
    border-radius: 14px
    border: 0.5px solid rgba(255,255,255,0.12)
    padding: 14px 16px 12px
    color: #fff

  .pm-header
    display: flex
    justify-content: space-between
    align-items: baseline
    margin-bottom: 12px

  .pm-title
    font-size: 13px
    font-weight: 600
    letter-spacing: 0.02em
    color: rgba(255,255,255,0.9)
    text-transform: uppercase

  .pm-source
    font-size: 10px
    color: rgba(255,255,255,0.35)
    letter-spacing: 0.05em

  .pm-loading
    font-size: 12px
    color: rgba(255,255,255,0.4)
    padding: 8px 0

  .pm-row
    margin-bottom: 10px

  .pm-row:last-child
    margin-bottom: 0

  .pm-question
    font-size: 11px
    color: rgba(255,255,255,0.5)
    margin-bottom: 3px
    white-space: nowrap
    overflow: hidden
    text-overflow: ellipsis

  .pm-result
    display: flex
    justify-content: space-between
    align-items: baseline
    margin-bottom: 4px

  .pm-candidate
    font-size: 13px
    font-weight: 500
    color: rgba(255,255,255,0.9)

  .pm-candidate.dem
    color: #5b9cf6

  .pm-candidate.rep
    color: #f27060

  .pm-candidate.neutral
    color: rgba(255,255,255,0.85)

  .pm-pct
    font-size: 14px
    font-weight: 600
    color: rgba(255,255,255,0.9)

  .pm-bar-bg
    height: 3px
    background: rgba(255,255,255,0.1)
    border-radius: 2px
    overflow: hidden

  .pm-bar
    height: 100%
    border-radius: 2px
    background: rgba(255,255,255,0.4)

  .pm-bar.dem
    background: #5b9cf6

  .pm-bar.rep
    background: #f27060

  #pm-updated
    font-size: 10px
    color: rgba(255,255,255,0.25)
    margin-top: 10px
    text-align: right
"""
